# NexT

Fork form https://github.com/iissnan/hexo-theme-next



## Change


- Add custom image-backgroud
- More Big(16px) font size
- Add custom tag style

